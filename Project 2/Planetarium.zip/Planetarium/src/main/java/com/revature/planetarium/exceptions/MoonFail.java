package com.revature.planetarium.exceptions;

public class MoonFail extends RuntimeException {
    public MoonFail(String message) {
        super(message);
    }
}
