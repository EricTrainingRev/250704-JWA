package com.revature.planetarium.exceptions;

public class UserFail extends RuntimeException{
    public UserFail(String message){
        super(message);
    }
}
