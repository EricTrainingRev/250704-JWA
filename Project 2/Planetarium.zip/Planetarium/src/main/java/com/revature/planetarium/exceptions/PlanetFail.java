package com.revature.planetarium.exceptions;

public class PlanetFail extends RuntimeException{

    public PlanetFail(String message) {
        super(message);
    }
    
}
