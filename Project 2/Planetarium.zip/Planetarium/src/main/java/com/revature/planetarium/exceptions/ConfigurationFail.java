package com.revature.planetarium.exceptions;

public class ConfigurationFail extends Exception {
    public ConfigurationFail(String message) {
        super(message);
    }
}
