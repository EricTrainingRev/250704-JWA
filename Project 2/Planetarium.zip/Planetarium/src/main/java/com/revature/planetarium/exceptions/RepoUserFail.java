package com.revature.planetarium.exceptions;

public class RepoUserFail extends RuntimeException {
    public RepoUserFail(String message) {
        super(message);
    }
}
