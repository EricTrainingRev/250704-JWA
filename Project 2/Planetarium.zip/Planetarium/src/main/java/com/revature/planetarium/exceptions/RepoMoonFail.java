package com.revature.planetarium.exceptions;

public class RepoMoonFail extends RuntimeException {
    public RepoMoonFail(String message) {
        super(message);
    }
}
